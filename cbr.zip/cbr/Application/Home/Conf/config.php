﻿<?php
	return array(
	//'配置项'=>'配置值'
	'DB_TYPE'=>'mysql',		//配置数据库的类型
	'DB_HOST'=>'127.0.0.1',	//数据库服务器的地址
	'DB_NAME'=>'phplyb',	//数据库名称
	'DB_USER'=>'root',		//数据库用户
	'DB_PWD'=>'123456',		//数据库用户密码
	'DB_PORT'=>'3306',		//数据库的端口
);
